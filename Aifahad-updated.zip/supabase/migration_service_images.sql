-- ============================================================
-- Migration: add cover images to services
-- Run this ONCE in the Supabase SQL Editor for the existing project
-- (schema.sql only runs on a brand-new project, so this brings an
-- already-live database up to date). Safe to re-run.
-- ============================================================

alter table services add column if not exists image_url text;

-- Backfill only rows that don't have an image yet, so it never
-- overwrites a custom image you already set from /admin/services.
update services set image_url = '/service-covers/' || category || '.svg'
where image_url is null;
